const {useState, useEffect, useMemo, useRef} = React;

/* ---------------- MOCK DATA ---------------- */

const PERSONNEL = [
  {armyNo:"JC-118820P", name:"Rawat, V.", rank:"Hav", unit:"2 GRENADIERS", status:"ON DUTY", rest:0},
  {armyNo:"IC-56231X", name:"Menon, S.", rank:"Lt", unit:"2 GRENADIERS", status:"ON DUTY", rest:0},
  {armyNo:"JC-224871K", name:"Bhatt, A.", rank:"Nb Sub", unit:"HQ COY", rest:6, status:"REST"},
  {armyNo:"NK-994102", name:"Chauhan, R.", rank:"Sep", unit:"HQ COY", rest:0, status:"AVAILABLE"},
  {armyNo:"JC-330019L", name:"Yadav, D.", rank:"Nk", unit:"3 PARA", status:"ON DUTY", rest:0},
  {armyNo:"NK-771145", name:"Singh, P.", rank:"Sep", unit:"3 PARA", status:"LEAVE", rest:0},
  {armyNo:"IC-70234R", name:"Kulkarni, N.", rank:"Capt", unit:"HQ COY", status:"AVAILABLE", rest:0},
  {armyNo:"JC-441982", name:"Thapa, B.", rank:"Hav", unit:"2 GRENADIERS", status:"AVAILABLE", rest:0},
];

const POSTS = [
  {id:"PST-01", name:"Main Gate", priority:"HIGH", manpower:2, filled:2},
  {id:"PST-02", name:"Armoury", priority:"HIGH", manpower:2, filled:1},
  {id:"PST-03", name:"Perimeter — North", priority:"MED", manpower:3, filled:3},
  {id:"PST-04", name:"QRT Standby", priority:"HIGH", manpower:4, filled:3},
  {id:"PST-05", name:"Officers' Mess", priority:"LOW", manpower:1, filled:1},
];

const DUTY_ROSTER = [
  {shift:"0600–1400", post:"Main Gate", personnel:["JC-118820P Rawat","NK-994102 Chauhan"]},
  {shift:"0600–1400", post:"Armoury", personnel:["IC-56231X Menon"]},
  {shift:"1400–2200", post:"Perimeter — North", personnel:["JC-330019L Yadav","JC-441982 Thapa","IC-70234R Kulkarni"]},
  {shift:"2200–0600", post:"QRT Standby", personnel:["JC-118820P Rawat","JC-330019L Yadav","JC-441982 Thapa"]},
];

const WEAPONS = [
  {serial:"INSAS-4471", type:"INSAS Rifle", status:"ISSUED", holder:"JC-118820P Rawat", qr:"WPN-4471"},
  {serial:"INSAS-4472", type:"INSAS Rifle", status:"IN ARMOURY", holder:"—", qr:"WPN-4472"},
  {serial:"GLOCK-0091", type:"Glock 17", status:"ISSUED", holder:"IC-56231X Menon", qr:"WPN-0091"},
  {serial:"INSAS-4480", type:"INSAS Rifle", status:"ISSUED", holder:"JC-330019L Yadav", qr:"WPN-4480"},
  {serial:"LMG-0012", type:"LMG", status:"IN ARMOURY", holder:"—", qr:"WPN-0012"},
  {serial:"INSAS-4491", type:"INSAS Rifle", status:"MAINTENANCE", holder:"—", qr:"WPN-4491"},
];

const ALERTS = [
  {level:"amber", text:"Nb Sub Bhatt, A. rest period ends in 40 min — reassign PST-02 relief"},
  {level:"danger", text:"Armoury PST-02 understaffed: 1 of 2 filled"},
  {level:"steel", text:"6 weapons due for quarterly maintenance check"},
];

const AUDIT_LOG = [
  {ts:"29 JUL 06:02", event:"Weapon issued", detail:"INSAS-4471 → JC-118820P Rawat", by:"Sys/QR"},
  {ts:"29 JUL 05:58", event:"Duty assigned", detail:"PST-01 Main Gate, 0600–1400", by:"Capt Kulkarni"},
  {ts:"29 JUL 05:40", event:"Leave approved", detail:"NK-771145 Singh — 3 days", by:"Adjt"},
  {ts:"28 JUL 22:10", event:"Weapon returned", detail:"GLOCK-0091 ← IC-56231X Menon", by:"Sys/QR"},
];

/* ---------------- SMALL UI PARTS ---------------- */

function StatusChip({status}) {
  const map = {
    "ON DUTY": {bg:"var(--khaki)", fg:"var(--bg)"},
    "AVAILABLE": {bg:"var(--steel)", fg:"#fff"},
    "REST": {bg:"var(--amber)", fg:"var(--bg)"},
    "LEAVE": {bg:"var(--line)", fg:"var(--ink-dim)"},
    "ISSUED": {bg:"var(--khaki)", fg:"var(--bg)"},
    "IN ARMOURY": {bg:"var(--steel)", fg:"#fff"},
    "MAINTENANCE": {bg:"var(--danger)", fg:"#fff"},
  };
  const s = map[status] || {bg:"var(--line)", fg:"var(--ink)"};
  return <span className="chip" style={{background:s.bg,color:s.fg}}>{status}</span>;
}

function PriorityTag({p}) {
  const c = p==="HIGH" ? "var(--danger)" : p==="MED" ? "var(--amber)" : "var(--ink-dim)";
  return <span className="mono" style={{color:c, fontSize:11, fontWeight:600, letterSpacing:'.05em'}}>{p}</span>;
}

function Panel({title, eyebrow, children, right}) {
  return (
    <div style={{background:'var(--panel)', border:'1px solid var(--line)', borderRadius:'var(--radius)'}}>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'12px 16px', borderBottom:'1px solid var(--line)'}}>
        <div>
          {eyebrow && <div className="mono" style={{fontSize:10, color:'var(--khaki)', letterSpacing:'.1em', marginBottom:2}}>{eyebrow}</div>}
          <div className="disp" style={{fontSize:15, fontWeight:600}}>{title}</div>
        </div>
        {right}
      </div>
      <div style={{padding:16}}>{children}</div>
    </div>
  );
}

/* ---------------- LOGIN ---------------- */

function Login({onLogin}) {
  const [id, setId] = useState("");
  const [pw, setPw] = useState("");
  const [err, setErr] = useState("");
  const submit = (e) => {
    e.preventDefault();
    if (!id.trim() || !pw.trim()) { setErr("Enter service ID and password."); return; }
    onLogin(id.trim());
  };
  return (
    <div style={{minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--bg)', padding:20}}>
      <div className="fade-in" style={{width:380, border:'1px solid var(--line)', background:'var(--panel)', borderRadius:'var(--radius)'}}>
        <div className="scanline" style={{padding:'28px 28px 20px', borderBottom:'1px solid var(--line)'}}>
          <div className="mono" style={{fontSize:11, color:'var(--khaki)', letterSpacing:'.15em'}}>DDMS // SECURE ACCESS</div>
          <div className="disp" style={{fontSize:26, fontWeight:700, marginTop:6}}>Defence Duty<br/>Management System</div>
        </div>
        <form onSubmit={submit} style={{padding:'24px 28px 28px'}}>
          <label className="mono" style={{fontSize:10, color:'var(--ink-dim)', letterSpacing:'.08em'}}>ARMY / SERVICE NO.</label>
          <input value={id} onChange={e=>setId(e.target.value)} placeholder="JC-118820P"
            style={{width:'100%', marginTop:6, marginBottom:16, padding:'10px 12px', background:'var(--panel-2)', border:'1px solid var(--line)', color:'var(--ink)', fontFamily:'IBM Plex Mono', borderRadius:'2px'}} />
          <label className="mono" style={{fontSize:10, color:'var(--ink-dim)', letterSpacing:'.08em'}}>PASSWORD</label>
          <input value={pw} onChange={e=>setPw(e.target.value)} type="password" placeholder="••••••••"
            style={{width:'100%', marginTop:6, marginBottom:8, padding:'10px 12px', background:'var(--panel-2)', border:'1px solid var(--line)', color:'var(--ink)', fontFamily:'IBM Plex Mono', borderRadius:'2px'}} />
          {err && <div className="mono" style={{color:'var(--danger)', fontSize:11, marginBottom:8}}>{err}</div>}
          <button type="submit" className="disp" style={{width:'100%', marginTop:12, padding:'11px', background:'var(--khaki)', color:'var(--bg)', border:'none', fontWeight:600, fontSize:14, letterSpacing:'.05em', cursor:'pointer', borderRadius:'2px'}}>
            Authenticate
          </button>
          <div className="mono" style={{fontSize:10, color:'var(--ink-dim)', marginTop:14, textAlign:'center'}}>JWT-secured · any credentials work in this preview</div>
        </form>
      </div>
    </div>
  );
}

/* ---------------- DASHBOARD ---------------- */

function Dashboard({user}) {
  const onDuty = PERSONNEL.filter(p=>p.status==="ON DUTY").length;
  const available = PERSONNEL.filter(p=>p.status==="AVAILABLE").length;
  const issued = WEAPONS.filter(w=>w.status==="ISSUED").length;
  const chartRef = useRef(null);

  useEffect(() => {
    const ctx = chartRef.current.getContext('2d');
    const isLight = document.documentElement.getAttribute('data-theme')==='light';
    const grid = isLight ? '#d8d3c2' : '#343d49';
    const ink = isLight ? '#6b6656' : '#9aa3ad';
    const chart = new Chart(ctx, {
      type:'bar',
      data:{
        labels:['Main Gate','Armoury','Perimeter N','QRT Standby',"Off. Mess"],
        datasets:[
          {label:'Required', data: POSTS.map(p=>p.manpower), backgroundColor:'transparent', borderColor: isLight?'#8a9a6f':'#5f6b4d', borderWidth:1.5},
          {label:'Filled', data: POSTS.map(p=>p.filled), backgroundColor:'#8a9a6f'}
        ]
      },
      options:{
        responsive:true, maintainAspectRatio:false,
        plugins:{legend:{labels:{color:ink, font:{family:'IBM Plex Mono', size:10}}}},
        scales:{
          x:{ticks:{color:ink, font:{family:'IBM Plex Mono', size:10}}, grid:{color:grid}},
          y:{ticks:{color:ink, font:{family:'IBM Plex Mono', size:10}}, grid:{color:grid}, beginAtZero:true}
        }
      }
    });
    return ()=>chart.destroy();
  }, []);

  return (
    <div className="fade-in" style={{display:'grid', gap:16}}>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(180px,1fr))', gap:12}}>
        {[
          {label:'On Duty Now', val:onDuty, sub:`of ${PERSONNEL.length} personnel`},
          {label:'Available', val:available, sub:'ready for tasking'},
          {label:'Weapons Issued', val:issued, sub:`of ${WEAPONS.length} in registry`},
          {label:'Active Alerts', val:ALERTS.length, sub:'require attention'},
        ].map((s,i)=>(
          <div key={i} style={{border:'1px solid var(--line)', background:'var(--panel)', padding:16, borderRadius:'var(--radius)'}}>
            <div className="mono" style={{fontSize:10, color:'var(--ink-dim)', letterSpacing:'.08em'}}>{s.label.toUpperCase()}</div>
            <div className="disp" style={{fontSize:34, fontWeight:700, margin:'4px 0 2px', color:'var(--khaki)'}}>{s.val}</div>
            <div style={{fontSize:12, color:'var(--ink-dim)'}}>{s.sub}</div>
          </div>
        ))}
      </div>

      <div style={{display:'grid', gridTemplateColumns:'1.3fr 1fr', gap:16}}>
        <Panel title="Post Manning" eyebrow="Required vs. Filled">
          <div style={{height:220}}><canvas ref={chartRef}></canvas></div>
        </Panel>
        <Panel title="Alerts" eyebrow="Live">
          <div style={{display:'grid', gap:10}}>
            {ALERTS.map((a,i)=>(
              <div key={i} style={{display:'flex', gap:10, alignItems:'flex-start', paddingBottom:10, borderBottom: i<ALERTS.length-1?'1px solid var(--line)':'none'}}>
                <div style={{width:8,height:8,borderRadius:'50%', marginTop:5, background:`var(--${a.level})`, flexShrink:0}}></div>
                <div style={{fontSize:13, lineHeight:1.4}}>{a.text}</div>
              </div>
            ))}
          </div>
        </Panel>
      </div>

      <Panel title="Today's Duty Slots" eyebrow={`Shift board · ${new Date().toDateString()}`}>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%', borderCollapse:'collapse'}}>
            <thead>
              <tr className="mono" style={{fontSize:10, color:'var(--ink-dim)', letterSpacing:'.06em', textAlign:'left'}}>
                <th style={{padding:'0 8px 8px 0'}}>SHIFT</th>
                <th style={{padding:'0 8px 8px'}}>POST</th>
                <th style={{padding:'0 8px 8px'}}>PERSONNEL</th>
              </tr>
            </thead>
            <tbody>
              {DUTY_ROSTER.map((r,i)=>(
                <tr key={i} className="board-row">
                  <td className="mono" style={{padding:'10px 8px 10px 0', fontSize:12, color:'var(--khaki)'}}>{r.shift}</td>
                  <td style={{padding:'10px 8px', fontSize:13}}>{r.post}</td>
                  <td style={{padding:'10px 8px', fontSize:12, color:'var(--ink-dim)'}}>{r.personnel.join(', ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}

/* ---------------- DUTY ROSTER (full) ---------------- */

function RosterView() {
  const [filter, setFilter] = useState("ALL");
  const units = ["ALL", ...new Set(PERSONNEL.map(p=>p.unit))];
  const rows = filter==="ALL" ? PERSONNEL : PERSONNEL.filter(p=>p.unit===filter);
  return (
    <div className="fade-in" style={{display:'grid', gap:16}}>
      <Panel title="Duty Roster" eyebrow="Personnel & shift status" right={
        <select value={filter} onChange={e=>setFilter(e.target.value)}
          className="mono" style={{background:'var(--panel-2)', color:'var(--ink)', border:'1px solid var(--line)', padding:'6px 10px', fontSize:12, borderRadius:'2px'}}>
          {units.map(u=><option key={u} value={u}>{u}</option>)}
        </select>
      }>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%', borderCollapse:'collapse'}}>
            <thead>
              <tr className="mono" style={{fontSize:10, color:'var(--ink-dim)', letterSpacing:'.06em', textAlign:'left'}}>
                <th style={{padding:'0 8px 10px 0'}}>ARMY NO.</th>
                <th style={{padding:'0 8px 10px'}}>NAME</th>
                <th style={{padding:'0 8px 10px'}}>RANK</th>
                <th style={{padding:'0 8px 10px'}}>UNIT</th>
                <th style={{padding:'0 8px 10px'}}>STATUS</th>
                <th style={{padding:'0 8px 10px'}}>REST (HRS)</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((p,i)=>(
                <tr key={i} className="board-row">
                  <td className="mono" style={{padding:'10px 8px 10px 0', fontSize:12}}>{p.armyNo}</td>
                  <td style={{padding:'10px 8px', fontSize:13, fontWeight:500}}>{p.name}</td>
                  <td className="mono" style={{padding:'10px 8px', fontSize:12, color:'var(--khaki)'}}>{p.rank}</td>
                  <td style={{padding:'10px 8px', fontSize:12, color:'var(--ink-dim)'}}>{p.unit}</td>
                  <td style={{padding:'10px 8px'}}><StatusChip status={p.status}/></td>
                  <td className="mono" style={{padding:'10px 8px', fontSize:12}}>{p.rest || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>

      <Panel title="Post Requirements" eyebrow="Manning priority">
        <div style={{display:'grid', gap:10}}>
          {POSTS.map((p,i)=>(
            <div key={i} className="board-row" style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 0'}}>
              <div style={{display:'flex', gap:14, alignItems:'center'}}>
                <span className="mono" style={{fontSize:11, color:'var(--ink-dim)'}}>{p.id}</span>
                <span style={{fontSize:13, fontWeight:500}}>{p.name}</span>
                <PriorityTag p={p.priority}/>
              </div>
              <div className="mono" style={{fontSize:12, color: p.filled<p.manpower ? 'var(--danger)' : 'var(--khaki)'}}>
                {p.filled} / {p.manpower} filled
              </div>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

/* ---------------- WEAPONS + QR ---------------- */

function QRScanModal({onClose, onScan}) {
  const [scanning, setScanning] = useState(true);
  useEffect(()=>{
    const t = setTimeout(()=>{ setScanning(false); }, 1600);
    return ()=>clearTimeout(t);
  },[]);
  return (
    <div style={{position:'fixed', inset:0, background:'rgba(0,0,0,.6)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:50}} onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{width:320, background:'var(--panel)', border:'1px solid var(--line)', borderRadius:'2px', overflow:'hidden'}}>
        <div style={{padding:'12px 16px', borderBottom:'1px solid var(--line)', display:'flex', justifyContent:'space-between'}}>
          <span className="mono" style={{fontSize:11, letterSpacing:'.08em', color:'var(--khaki)'}}>QR SCAN — WEAPON</span>
          <button onClick={onClose} style={{background:'none', border:'none', color:'var(--ink-dim)', cursor:'pointer'}}>✕</button>
        </div>
        <div className="scanline" style={{height:180, margin:16, border:'1px dashed var(--line)', display:'flex', alignItems:'center', justifyContent:'center', position:'relative'}}>
          <div className="mono" style={{fontSize:11, color:'var(--ink-dim)'}}>{scanning ? 'Aligning frame…' : 'Match found'}</div>
        </div>
        <div style={{padding:'0 16px 16px'}}>
          {scanning ? (
            <div className="mono" style={{fontSize:11, color:'var(--ink-dim)', textAlign:'center'}}>Scanning…</div>
          ) : (
            <button onClick={()=>{onScan(); onClose();}} className="disp" style={{width:'100%', padding:'10px', background:'var(--khaki)', color:'var(--bg)', border:'none', fontWeight:600, fontSize:13, cursor:'pointer', borderRadius:'2px'}}>
              Confirm WPN-4472 Return
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

function WeaponsView() {
  const [weapons, setWeapons] = useState(WEAPONS);
  const [showScan, setShowScan] = useState(false);

  const handleScanReturn = () => {
    setWeapons(prev => prev.map(w => w.serial==="INSAS-4472" ? {...w, status:"IN ARMOURY", holder:"—"} : w));
  };

  return (
    <div className="fade-in" style={{display:'grid', gap:16}}>
      <Panel title="Weapon & Ammunition Registry" eyebrow="Issue / return status" right={
        <button onClick={()=>setShowScan(true)} className="mono" style={{background:'var(--steel)', color:'#fff', border:'none', padding:'7px 12px', fontSize:11, letterSpacing:'.06em', cursor:'pointer', borderRadius:'2px'}}>
          ▣ SCAN QR
        </button>
      }>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%', borderCollapse:'collapse'}}>
            <thead>
              <tr className="mono" style={{fontSize:10, color:'var(--ink-dim)', letterSpacing:'.06em', textAlign:'left'}}>
                <th style={{padding:'0 8px 10px 0'}}>SERIAL</th>
                <th style={{padding:'0 8px 10px'}}>TYPE</th>
                <th style={{padding:'0 8px 10px'}}>STATUS</th>
                <th style={{padding:'0 8px 10px'}}>HOLDER</th>
                <th style={{padding:'0 8px 10px'}}>QR TAG</th>
              </tr>
            </thead>
            <tbody>
              {weapons.map((w,i)=>(
                <tr key={i} className="board-row">
                  <td className="mono" style={{padding:'10px 8px 10px 0', fontSize:12}}>{w.serial}</td>
                  <td style={{padding:'10px 8px', fontSize:13}}>{w.type}</td>
                  <td style={{padding:'10px 8px'}}><StatusChip status={w.status}/></td>
                  <td style={{padding:'10px 8px', fontSize:12, color:'var(--ink-dim)'}}>{w.holder}</td>
                  <td className="mono" style={{padding:'10px 8px', fontSize:11, color:'var(--khaki)'}}>{w.qr}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
      {showScan && <QRScanModal onClose={()=>setShowScan(false)} onScan={handleScanReturn} />}
    </div>
  );
}

/* ---------------- REPORTS ---------------- */

function ReportsView() {
  const [generating, setGenerating] = useState(null);
  const reports = [
    {id:'duty', name:'Duty Report', desc:'Full roster with shift assignments, current cycle'},
    {id:'weapon', name:'Weapon Report', desc:'Issue/return log and armoury holdings'},
    {id:'attendance', name:'Attendance Report', desc:'Personnel attendance & leave summary'},
  ];
  const trigger = (id) => {
    setGenerating(id);
    setTimeout(()=>setGenerating(null), 1200);
  };
  return (
    <div className="fade-in" style={{display:'grid', gap:16}}>
      <Panel title="Reports" eyebrow="Generated as PDF · iText">
        <div style={{display:'grid', gap:12}}>
          {reports.map(r=>(
            <div key={r.id} className="board-row" style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'14px 0'}}>
              <div>
                <div style={{fontSize:14, fontWeight:600}}>{r.name}</div>
                <div style={{fontSize:12, color:'var(--ink-dim)', marginTop:2}}>{r.desc}</div>
              </div>
              <button onClick={()=>trigger(r.id)} className="mono" style={{background: generating===r.id ? 'var(--line)' : 'var(--khaki)', color: generating===r.id ? 'var(--ink-dim)' : 'var(--bg)', border:'none', padding:'8px 14px', fontSize:11, letterSpacing:'.06em', cursor:'pointer', borderRadius:'2px', minWidth:110}}>
                {generating===r.id ? 'BUILDING…' : '⬇ DOWNLOAD'}
              </button>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Audit Log" eyebrow="All assignments & transactions">
        <div style={{display:'grid', gap:0}}>
          {AUDIT_LOG.map((a,i)=>(
            <div key={i} className="board-row" style={{display:'grid', gridTemplateColumns:'110px 140px 1fr 110px', gap:10, padding:'10px 0', alignItems:'center'}}>
              <span className="mono" style={{fontSize:11, color:'var(--ink-dim)'}}>{a.ts}</span>
              <span style={{fontSize:12, fontWeight:600, color:'var(--khaki)'}}>{a.event}</span>
              <span style={{fontSize:12}}>{a.detail}</span>
              <span className="mono" style={{fontSize:11, color:'var(--ink-dim)', textAlign:'right'}}>{a.by}</span>
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

/* ---------------- PERSONNEL / AVAILABILITY ---------------- */

function PersonnelView() {
  return (
    <div className="fade-in" style={{display:'grid', gap:16}}>
      <Panel title="Personnel & Rest Schedule" eyebrow="Availability">
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(230px,1fr))', gap:12}}>
          {PERSONNEL.map((p,i)=>(
            <div key={i} style={{border:'1px solid var(--line)', padding:14, borderRadius:'2px', background:'var(--panel-2)'}}>
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start'}}>
                <div>
                  <div style={{fontSize:14, fontWeight:600}}>{p.name}</div>
                  <div className="mono" style={{fontSize:11, color:'var(--ink-dim)', marginTop:2}}>{p.rank} · {p.armyNo}</div>
                </div>
                <StatusChip status={p.status}/>
              </div>
              <div className="stenciled" style={{margin:'10px 0'}}></div>
              <div style={{fontSize:12, color:'var(--ink-dim)'}}>{p.unit}</div>
              {p.rest>0 && <div className="mono" style={{fontSize:11, color:'var(--amber)', marginTop:6}}>Rest ends in {p.rest}h</div>}
            </div>
          ))}
        </div>
      </Panel>
    </div>
  );
}

/* ---------------- SHELL ---------------- */

function Shell({user, onLogout}) {
  const [page, setPage] = useState('dashboard');
  const [theme, setTheme] = useState('dark');

  useEffect(()=>{
    document.documentElement.setAttribute('data-theme', theme);
  },[theme]);

  const nav = [
    {id:'dashboard', label:'Dashboard'},
    {id:'roster', label:'Duty Roster'},
    {id:'weapons', label:'Weapons'},
    {id:'personnel', label:'Personnel'},
    {id:'reports', label:'Reports'},
  ];

  const pages = {
    dashboard: <Dashboard user={user} />,
    roster: <RosterView />,
    weapons: <WeaponsView />,
    personnel: <PersonnelView />,
    reports: <ReportsView />,
  };

  return (
    <div style={{minHeight:'100vh', display:'flex'}}>
      {/* Side rail */}
      <div style={{width:210, borderRight:'1px solid var(--line)', background:'var(--panel)', display:'flex', flexDirection:'column', flexShrink:0}}>
        <div style={{padding:'20px 18px', borderBottom:'1px solid var(--line)'}}>
          <div className="mono" style={{fontSize:10, color:'var(--khaki)', letterSpacing:'.12em'}}>DDMS</div>
          <div className="disp" style={{fontSize:16, fontWeight:700, marginTop:2}}>Duty Board</div>
        </div>
        <nav style={{padding:'14px 10px', display:'grid', gap:2, flex:1}}>
          {nav.map(n=>(
            <button key={n.id} onClick={()=>setPage(n.id)}
              className="disp"
              style={{
                textAlign:'left', padding:'10px 12px', background: page===n.id ? 'var(--panel-2)' : 'transparent',
                border:'none', borderLeft: page===n.id ? '2px solid var(--khaki)' : '2px solid transparent',
                color: page===n.id ? 'var(--ink)' : 'var(--ink-dim)', fontSize:13, fontWeight:500, cursor:'pointer', borderRadius:'2px'
              }}>
              {n.label}
            </button>
          ))}
        </nav>
        <div style={{padding:14, borderTop:'1px solid var(--line)'}}>
          <div className="mono" style={{fontSize:10, color:'var(--ink-dim)', marginBottom:8}}>{user}</div>
          <button onClick={onLogout} className="mono" style={{width:'100%', padding:'7px', background:'transparent', border:'1px solid var(--line)', color:'var(--ink-dim)', fontSize:11, cursor:'pointer', borderRadius:'2px'}}>
            SIGN OUT
          </button>
        </div>
      </div>

      {/* Main */}
      <div style={{flex:1, display:'flex', flexDirection:'column', minWidth:0}}>
        <div style={{padding:'14px 24px', borderBottom:'1px solid var(--line)', display:'flex', justifyContent:'space-between', alignItems:'center'}}>
          <div>
            <div className="mono" style={{fontSize:10, color:'var(--ink-dim)', letterSpacing:'.08em'}}>{new Date().toDateString().toUpperCase()}</div>
            <div className="disp" style={{fontSize:18, fontWeight:600}}>{nav.find(n=>n.id===page).label}</div>
          </div>
          <div style={{display:'flex', gap:10, alignItems:'center'}}>
            <span className="chip" style={{background:'var(--danger)', color:'#fff'}}>{ALERTS.length} ALERTS</span>
            <button onClick={()=>setTheme(t=>t==='dark'?'light':'dark')}
              className="mono" style={{background:'var(--panel-2)', border:'1px solid var(--line)', color:'var(--ink)', padding:'6px 10px', fontSize:11, cursor:'pointer', borderRadius:'2px'}}>
              {theme==='dark' ? '☾ DARK' : '☀ LIGHT'}
            </button>
          </div>
        </div>
        <div style={{padding:24, flex:1, overflow:'auto'}}>
          {pages[page]}
        </div>
      </div>
    </div>
  );
}

function App() {
  const [user, setUser] = useState(null);
  if (!user) return <Login onLogin={setUser} />;
  return <Shell user={user} onLogout={()=>setUser(null)} />;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
